// data/frameworksData.js
export const frameworksData = {
  marketSizing: [
    // Data for market sizing section
  ],
  profitability: [
    // Data for profitability section
  ],
  mAndA: [
    // Data for M&A section
  ],
  // Add more sections as needed
};
