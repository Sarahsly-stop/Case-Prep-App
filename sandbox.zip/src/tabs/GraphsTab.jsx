// GraphsTab.js
import React from "react";

function GraphsTab() {
  return (
    <div>
      <h2>Graphs Tab</h2>
      <p>This is the content for the Graphs tab.</p>
    </div>
  );
}

export default GraphsTab;
