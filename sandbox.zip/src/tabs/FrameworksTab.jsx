// FrameworksTab.js
import React from "react";
import "./frameworks.css";

function FrameworksTab() {
  return (
    <div className="tab">
      <h2>Frameworks Tab</h2>
      <p>This is the content for the Frameworks tab.</p>
    </div>
  );
}

export default FrameworksTab;
