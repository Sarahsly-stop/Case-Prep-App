// MathTab.js
import React from "react";

function MathTab() {
  return (
    <div>
      <h2>Math Tab</h2>
      <p>This is the content for the Math tab.</p>
    </div>
  );
}

export default MathTab;
